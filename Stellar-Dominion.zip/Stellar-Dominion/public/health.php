<?php echo "ok ", phpversion();

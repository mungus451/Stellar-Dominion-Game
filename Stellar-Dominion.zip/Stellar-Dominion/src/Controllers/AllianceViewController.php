<?php

namespace App\Controllers;

class AllianceViewController extends BaseController
{
    // Logic for viewing other alliances will go here
}

<?php
// template/includes/profile/card_header.php
?>
<section class="content-box rounded-xl p-5">
    <div class="flex items-start justify-between gap-4">
        <div class="flex items-start gap-4">
            <img src="<?php echo htmlspecialchars($avatar_path); ?>" alt="Avatar"
                 class="w-20 h-20 md:w-24 md:h-24 rounded-xl object-cover ring-2 ring-cyan-700/40">
            <div>
                <div class="flex items-center gap-2 flex-wrap">
                    <h1 class="font-title text-2xl text-white"><?php echo htmlspecialchars($name); ?></h1>
                    <?php if ($is_rival): ?><span class="px-2 py-0.5 text-xs rounded bg-red-700/30 text-red-300 border border-red-600/50">RIVAL</span><?php endif; ?>
                    <?php if ($is_self): ?><span class="px-2 py-0.5 text-xs rounded bg-cyan-700/30 text-cyan-300 border border-cyan-600/50">You</span><?php endif; ?>
                    <?php if ($is_same_alliance): ?><span class="px-2 py-0.5 text-xs rounded bg-indigo-700/30 text-indigo-300 border border-indigo-600/50">Same Alliance</span><?php endif; ?>
                </div>

                <div class="mt-1 text-gray-300 text-sm flex flex-wrap items-center gap-2">
                    <span><?php echo htmlspecialchars($race); ?></span>
                    <span>•</span>
                    <span><?php echo htmlspecialchars($class); ?></span>
                    <span>•</span>
                    <span>Level <?php echo number_format((int)$level); ?></span>
                    <?php if ($alliance_tag && $alliance_id): ?>
                        <span>•</span>
                        <a class="text-cyan-400 hover:underline" href="/view_alliance.php?id=<?php echo (int)$alliance_id; ?>">
                            [<?php echo htmlspecialchars($alliance_tag); ?>] <?php echo htmlspecialchars($alliance_name ?? ''); ?>
                        </a>
                    <?php elseif ($alliance_tag): ?>
                        <span>•</span><span>[<?php echo htmlspecialchars($alliance_tag); ?>]</span>
                    <?php endif; ?>
                </div>

                <div class="mt-1 text-sm">
                    <?php if ($is_online): ?>
                        <span class="text-emerald-300">Online</span>
                    <?php else: ?>
                        <span class="text-gray-400">Offline</span>
                        <?php if (!empty($last_online_label)): ?><span class="text-gray-500"> • <?php echo htmlspecialchars($last_online_label); ?></span><?php endif; ?>
                    <?php endif; ?>
                </div>

                <!-- War Outcomes chips -->
                <?php if (!empty($war_outcome_chips)): ?>
                <div class="mt-2 flex flex-wrap gap-2">
                    <?php foreach ($war_outcome_chips as $lbl => $info):
                        $victor = ($info['result'] === 'Victor');
                        $cls = $victor
                            ? 'bg-emerald-700/25 text-emerald-200 border-emerald-500/40'
                            : 'bg-red-700/25 text-red-200 border-red-500/40';
                    ?>
                        <span class="px-2 py-0.5 text-xs rounded border <?php echo $cls; ?>" title="<?php echo htmlspecialchars($info['date'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
                            <?php echo htmlspecialchars($lbl); ?> — <?php echo htmlspecialchars($info['result']); ?>
                        </span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Invite (compact, only when allowed and target has no alliance) -->
        <?php if ($can_invite && !$is_self && !$target_alliance_id): ?>
            <form method="POST" action="/view_profile.php" class="shrink-0">
                <input type="hidden" name="csrf_token"  value="<?php echo htmlspecialchars($invite_csrf, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="csrf_action" value="invite">
                <input type="hidden" name="action"      value="alliance_invite">
                <input type="hidden" name="invitee_id"  value="<?php echo (int)$profile['id']; ?>">
                <button type="submit" class="bg-indigo-700 hover:bg-indigo-600 text-white text-xs font-semibold py-2 px-3 rounded-md">
                    Invite to Alliance
                </button>
            </form>
        <?php endif; ?>
    </div>

    <!-- Quick Stats -->
    <div class="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div class="bg-gray-900/60 border border-gray-700 rounded-lg p-3 text-center">
            <div class="text-gray-400 text-xs">Army Size</div>
            <div class="text-white text-lg font-semibold"><?php echo number_format((int)$army_size); ?></div>
        </div>
        <div class="bg-gray-900/60 border border-gray-700 rounded-lg p-3 text-center">
            <div class="text-gray-400 text-xs">Rank</div>
            <div class="text-white text-lg font-semibold"><?php echo $player_rank !== null ? number_format((int)$player_rank) : '—'; ?></div>
        </div>
        <div class="bg-gray-900/60 border border-gray-700 rounded-lg p-3 text-center">
            <div class="text-gray-400 text-xs">Wins</div>
            <div class="text-white text-lg font-semibold"><?php echo number_format((int)$wins); ?></div>
        </div>
        <div class="bg-gray-900/60 border border-gray-700 rounded-lg p-3 text-center">
            <div class="text-gray-400 text-xs">Today vs You</div>
            <div class="text-white text-lg font-semibold"><?php echo number_format((int)$h2h_today['count']); ?></div>
        </div>
    </div>
</section>

 </div>
        </div>
    </div>
    <footer class="bg-gray-900 bg-opacity-80 mt-16">
        <div class="container mx-auto px-6 py-8">
            <div class="flex flex-col items-center sm:flex-row sm:justify-between">
                <p class="text-sm text-gray-500">&copy; <?php echo date("Y"); ?> Cerberusrf Productions. All rights reserved.</p>
            </div>
        </div>
    </footer>
    <script src="/assets/js/main.js" defer></script>
</body>
</html>